🚑 AI Smart Ambulance Traffic Clearance System
📌 Overview

Traffic congestion often delays ambulances during medical emergencies, leading to loss of critical response time.
This project presents a web-based AI-assisted system that enables real-time coordination between ambulance drivers and traffic police, helping create a digital emergency corridor and reduce delays.

The system integrates live map tracking, machine learning–based traffic congestion prediction, and centralized coordination dashboards into a single scalable platform.

🎯 Problem Statement

Ambulances frequently get stuck in traffic.

Traffic police lack real-time visibility of ambulance movement.

Existing solutions are reactive and fragmented.

Delays during the golden hour can be life-threatening.

💡 Proposed Solution

A centralized web platform that:

Tracks ambulances live on a map.

Visually highlights emergency priority routes.

Predicts traffic congestion using machine learning.

Assists traffic police with data-driven decision support.

Provides coordinated emergency response instead of isolated tools.

🧠 Key Features

🚑 Ambulance View

Emergency mode activation

Live location tracking

Priority route (green corridor) visualization

👮 Traffic Police Dashboard

Real-time ambulance monitoring

Emergency status visibility

Decision-support insights

🤖 Machine Learning Module

Traffic congestion prediction (Low / Medium / High)

Trained on historical Kaggle traffic dataset

Feature engineering based on time and junction data

🏗 System Architecture
Frontend (HTML/CSS/JS + Leaflet)
        |
        | REST API
        |
Backend (Node.js / Express)
        |
        | ML Logic
        |
Python ML Module (Decision Tree)
        |
CSV Dataset (Kaggle Traffic Data)

🛠 Technology Stack
Frontend

HTML, CSS, JavaScript

Bootstrap

Leaflet.js with OpenStreetMap

Backend

Node.js (Express.js)

REST APIs

Machine Learning

Python

Pandas

Scikit-learn

Decision Tree Classifier

Data Source

Kaggle Public Traffic Dataset (CSV)

AI Logic

Rule-based decision assistance

ML-based traffic congestion prediction

📊 Machine Learning Details

Dataset: Historical traffic data from Kaggle

Features Used:

Hour of the day

Junction identifier

Target:

Traffic congestion level (Low / Medium / High)

Model:

Decision Tree Classifier

Purpose:

Predict congestion in advance to assist routing and traffic clearance planning

🔍 Novelty of the Project

Dedicated AI-assisted system for ambulance prioritization.

Predictive congestion analysis instead of only reactive routing.

Real-time coordination between ambulance and traffic police dashboards.

Centralized emergency management platform.

Lightweight, open-source, and scalable architecture.

▶️ How to Run the Project
1️⃣ Backend (Node.js)
cd backend
node server.js


Backend runs on:

http://127.0.0.1:5050

2️⃣ Machine Learning Module
cd backend
python3 app.py

3️⃣ Frontend

Open frontend/index.html using Live Server

Use Ambulance Login to activate emergency mode

Use Traffic Police Login to open police dashboard

🚀 Future Enhancements

Integration of ML predictions directly into routing decisions

Advanced route optimization (Dijkstra / A*)

Real-time signal automation (IoT integration)

LLM-based conversational assistant for traffic police

Database integration for persistent tracking and analytics

🏁 Conclusion

This project demonstrates how AI, machine learning, and web technologies can be combined to solve a real-world emergency response problem.
The prototype highlights system design, scalability, and intelligent coordination, making it suitable for smart city and emergency healthcare applications.