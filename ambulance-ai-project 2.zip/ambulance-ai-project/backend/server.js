const { exec } = require("child_process");
const express = require("express");
let demoRiskLevel = null;
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// Test route
app.get("/", (req, res) => {
  res.send("Backend is running 🚑");
});

// API route
app.get("/ambulance-location", (req, res) => {
  res.json({
    lat: 28.6139,
    lng: 77.209,
    status: "EMERGENCY",
  });
});

// 🧠 AI Decision API (WOW FEATURE)
//app.get("/ai-decision", (req, res) => {
//    res.json({
//        traffic_level: "HIGH",
//        risk_level: "CRITICAL",
//        confidence: 0.85,
//        recommended_action: "Clear Junction 2 immediately",
//        reason: "Peak hour congestion detected"
//    });
//});

// 🎬 DEMO MODE CONTROLLER
app.get("/demo-mode", (req, res) => {
  demoRiskLevel = req.query.level || null;
  res.send(`Demo mode set to ${demoRiskLevel}`);
});

app.get("/ai-decision", (req, res) => {
  // Example dynamic input (you can later link with map)
  const hour = new Date().getHours();
  const junction = 1;

  exec(`python3 app.py ${hour} ${junction}`, (error, stdout, stderr) => {
    if (error) {
      console.error(error);
      return res.status(500).send("ML error");
    }

    try {
      let result = JSON.parse(stdout);

      // 🎬 If demo mode active, override ML output
      if (demoRiskLevel) {
        result.risk_level = demoRiskLevel;
      }

      res.json(result);
    } catch (err) {
      console.error("Parse error:", err);
      res.status(500).send("Invalid ML response");
    }
  });
});

// 🔴 IMPORTANT: KEEP SERVER ALIVE
const PORT = 5050;

app.listen(PORT, () => {
  console.log("✅ Server started on port " + PORT);
});

// ⛔ DO NOT ADD ANY CODE BELOW THIS
