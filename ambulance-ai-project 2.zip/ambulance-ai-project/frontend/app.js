/***********************
 * CONFIG
 ***********************/
const BACKEND_URL = "http://127.0.0.1:5050";

/***********************
 * GLOBAL STATE
 ***********************/
let emergencyOn = false;
let routeLine = null;

// Hospital destination (dummy)
const hospitalLatLng = [28.6304, 77.2177];

/***********************
 * DOM ELEMENTS
 ***********************/
const ambulanceBtn = document.getElementById("ambulanceBtn");
const policeBtn = document.getElementById("policeBtn");
const statusText = document.getElementById("statusText");

/***********************
 * MAP INITIALIZATION
 ***********************/
const map = L.map("map").setView([28.6139, 77.2090], 13);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap contributors",
}).addTo(map);

const ambulanceMarker = L.marker([28.6139, 77.2090])
  .addTo(map)
  .bindPopup("🚑 Ambulance")
  .openPopup();

/***********************
 * BUTTON EVENTS
 ***********************/
ambulanceBtn.addEventListener("click", () => {
  emergencyOn = !emergencyOn;

  if (emergencyOn) {
    statusText.innerText = "Emergency Mode: ON";
    statusText.classList.remove("text-danger");
    statusText.classList.add("text-success");

    routeLine = L.polyline(
      [
        ambulanceMarker.getLatLng(),
        hospitalLatLng,
      ],
      { color: "green", weight: 5 }
    ).addTo(map);
  } else {
    statusText.innerText = "Emergency Mode: OFF";
    statusText.classList.remove("text-success");
    statusText.classList.add("text-danger");

    if (routeLine) {
      map.removeLayer(routeLine);
      routeLine = null;
    }
  }
});

policeBtn.addEventListener("click", () => {
  window.location.href = "police.html";
});

/***********************
 * BACKEND DATA FETCH
 ***********************/
async function fetchAmbulanceData() {
  try {
    const response = await fetch(`${BACKEND_URL}/ambulance-location`);
    const data = await response.json();

    // Update marker
    ambulanceMarker.setLatLng([data.lat, data.lng]);
    map.setView([data.lat, data.lng]);

    // Update route dynamically
    if (emergencyOn && routeLine) {
      routeLine.setLatLngs([
        [data.lat, data.lng],
        hospitalLatLng,
      ]);
    }

  } catch (error) {
    console.error("Error fetching ambulance data:", error);
  }
}

// Fetch backend data every 3 seconds
setInterval(fetchAmbulanceData, 3000);

console.log("Frontend connected to backend successfully 🚑");
