let lastSpokenMessage = "";
let lastRiskLevel = "";
let actionHandled = false;   // 🟡 police action flag

// ==============================
// 🎤 AI VOICE FUNCTION
// ==============================
function speakAI(message){
  const speech = new SpeechSynthesisUtterance(message);
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(speech);
}

// ==============================
// 🤖 LLM-STYLE EXPLANATION GENERATOR
// ==============================
function generateLLMExplanation(data){

  const hour = new Date().getHours();

  if(data.risk_level === "CRITICAL"){
    return `Based on high congestion patterns around ${hour}:00 hours, the AI recommends immediate signal clearance to prioritise ambulance movement and reduce emergency delay.`;
  }
  else if(data.risk_level === "HIGH"){
    return `Traffic density is increasing at nearby junctions. The system suggests proactive monitoring and route optimisation for smoother ambulance movement.`;
  }
  else{
    return `Traffic conditions are currently stable. The ambulance can continue on the optimal route with minimal interruption.`;
  }
}

// ==============================
// 🟡 ACTION TAKEN BUTTON FUNCTION
// ==============================
function handleActionTaken(){

  actionHandled = true;

  const actionText = document.getElementById("actionText");
  if(actionText){
    actionText.innerText = "Police action acknowledged. Monitoring traffic...";
  }

  speakAI("Police action recorded. Situation under monitoring.");
}

// ==============================
// 🗺️ MAP INITIALIZATION
// ==============================
const map = L.map("map").setView([28.6139,77.209],13);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{
 attribution:"&copy; OpenStreetMap contributors"
}).addTo(map);

let sourceMarker=null;
let destinationMarker=null;
let routingControl=null;
let ambulanceMarker=null;

let routeCoords=[];
let routeIndex=0;

// ==============================
// 📍 CLICK MAP → SET SOURCE & DESTINATION
// ==============================
map.on("click",(e)=>{

  if(!sourceMarker){

    sourceMarker=L.marker(e.latlng)
      .addTo(map)
      .bindPopup("🚑 Ambulance Source")
      .openPopup();

  }
  else if(!destinationMarker){

    destinationMarker=L.marker(e.latlng)
      .addTo(map)
      .bindPopup("🏥 Hospital Destination")
      .openPopup();

    drawRoute("green");
  }
});

// ==============================
// 🚦 DRAW REAL ROAD ROUTE
// ==============================
function drawRoute(color){

  if(!sourceMarker || !destinationMarker) return;

  if(routingControl){
    map.removeControl(routingControl);
  }

  routingControl = L.Routing.control({
    waypoints:[
      sourceMarker.getLatLng(),
      destinationMarker.getLatLng()
    ],
    lineOptions:{
      styles:[{color:color,weight:6}]
    },
    createMarker:()=>null,
    routeWhileDragging:false,
    addWaypoints:false,
    draggableWaypoints:false
  })
  .on("routesfound",function(e){

      routeCoords = e.routes[0].coordinates;
      routeIndex = 0;

      // ⏱️ REAL ETA CALCULATION
      const seconds = e.routes[0].summary.totalTime;
      const minutes = Math.round(seconds / 60);
      const etaElement = document.getElementById("eta");
      if(etaElement){
        etaElement.innerText = minutes + " minutes";
      }

      if(!ambulanceMarker){
        ambulanceMarker = L.marker(routeCoords[0])
          .addTo(map)
          .bindPopup("🚑 Ambulance")
          .openPopup();
      }

  })
  .addTo(map);
}

// ==============================
// 🚑 REAL ROAD AMBULANCE MOVEMENT
// ==============================
setInterval(()=>{

  if(!routeCoords.length || !ambulanceMarker) return;

  routeIndex++;

  if(routeIndex >= routeCoords.length){
      routeIndex = routeCoords.length-1;
  }

  ambulanceMarker.setLatLng(routeCoords[routeIndex]);

},500);

// ==============================
// 🔎 CITY SEARCH
// ==============================
async function searchCity(){

  const city=document.getElementById("cityInput").value;

  const res=await fetch(
    `https://nominatim.openstreetmap.org/search?format=json&q=${city}`
  );

  const data=await res.json();

  if(data.length>0){
    map.setView([data[0].lat,data[0].lon],13);
  }
}

// ==============================
// 🧠 AI DECISION FETCH
// ==============================
async function fetchAIDecision(){

  const thinkingText=document.getElementById("aiThinking");
  thinkingText.innerText="🧠 AI analyzing traffic patterns...";

  try{

    const res=await fetch("http://127.0.0.1:5050/ai-decision");
    const data=await res.json();

    // 🟡 If police clicked Action Taken → reduce risk
    if(actionHandled){
      data.risk_level = "LOW";
    }

    thinkingText.innerText="✅ AI Decision Updated";

    document.getElementById("riskLevel").innerText=data.risk_level;
    document.getElementById("confidence").innerText=data.confidence;
    document.getElementById("actionText").innerText=data.recommended_action;

    // 🤖 LLM STYLE EXPLANATION (NEW)
    document.getElementById("reasonText").innerText =
      generateLLMExplanation(data);

    const alertBox=document.getElementById("alertBox");
    alertBox.style.display=data.risk_level==="CRITICAL"?"block":"none";

    const bar=document.getElementById("confidenceBar");
    bar.style.width=(data.confidence*100)+"%";
    bar.classList.remove("bg-success","bg-warning","bg-danger");

    if(data.risk_level==="LOW") bar.classList.add("bg-success");
    else if(data.risk_level==="HIGH") bar.classList.add("bg-warning");
    else if(data.risk_level==="CRITICAL") bar.classList.add("bg-danger");

    // 🚑 ROUTE UPDATE ONLY WHEN RISK CHANGES
    if(data.risk_level !== lastRiskLevel){

      if(data.risk_level==="CRITICAL"){
        drawRoute("red");
      }
      else if(data.risk_level==="HIGH"){
        drawRoute("orange");
      }
      else{
        drawRoute("green");
      }

      lastRiskLevel = data.risk_level;
    }

    // 🎤 SMART VOICE
    const message=`Risk level ${data.risk_level}. ${data.recommended_action}`;

    if(message!==lastSpokenMessage){
      speakAI(message);
      lastSpokenMessage=message;
    }

  }catch(err){
    console.error("AI decision fetch error:",err);
  }
}

setInterval(fetchAIDecision,3000);
